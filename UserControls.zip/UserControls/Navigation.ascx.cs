﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HumanResourceApplication;

namespace HumanResourceApplication.UserControls
{
    public partial class Navigation : System.Web.UI.UserControl
    {
        //LoginService.LoginClient Proxy;
        HRMBAL.BALService Proxy;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();

            //var result = Proxy.GetRoleID(Convert.ToInt32(Session["EmpId"]), Session["Password"].ToString());

            var result = Proxy.GetRoleID(59,"pass!2211");

            lnkApproveLeave.NavigateUrl = String.Format(lnkApproveLeave.NavigateUrl, Request.QueryString["EmpId"]);

            lnkLeaveQuota.NavigateUrl = String.Format(lnkLeaveQuota.NavigateUrl, Request.QueryString["EmpId"]);

            lnkApplyAttendance.NavigateUrl = String.Format(lnkApplyAttendance.NavigateUrl, Request.QueryString["EmpId"]);

            lnkHoliday.NavigateUrl = String.Format(lnkHoliday.NavigateUrl, Request.QueryString["EmpId"]);

            lnkEmpReg.NavigateUrl = String.Format(lnkEmpReg.NavigateUrl, Request.QueryString["EmpId"]);

            lnkAttnReport.NavigateUrl = String.Format(lnkAttnReport.NavigateUrl, Request.QueryString["EmpId"]);

            lnkLeavReport.NavigateUrl = String.Format(lnkLeavReport.NavigateUrl, Request.QueryString["EmpId"]);

            if (result.RoleID == (int)HumanResourceApplication.HRMSEnums.Role.Executive)
            {
                //Display all the basic functionlities
            }
            else if (result.RoleID == (int)HumanResourceApplication.HRMSEnums.Role.Manager)
            {
                lnkApproveLeave.Visible = true;
            }
            else if (result.RoleID == (int)HumanResourceApplication.HRMSEnums.Role.HR)
            {
                lnkReports.Visible = true;
                lnkPayroll.Visible = true;
                lnkMasters.Visible = true;
                lnkApplyAttendance.Visible = true;
                lnkEmpReg.Visible = true;
            }
            else
            {

            }
        }
    }
}