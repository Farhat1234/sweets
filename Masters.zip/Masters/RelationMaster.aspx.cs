﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Masters
{
    public partial class RelationMaster : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.Relation relation;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.Relation relation;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            relation = new HRMDAL.Entites.Relation();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                relation.RelationType = txtRelationshipName.Text;
                Proxy.AddRelation(relation);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}