﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Masters
{
    public partial class NotInOfficeMaster : System.Web.UI.Page
    {
        //DailyAttend.DailyAttendanceClient Proxy;
        //DailyAttend.NotInOffice notinoffice;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.NotInOffice notinoffice;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            notinoffice = new HRMDAL.Entites.NotInOffice();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                notinoffice.NIOType = txtNIOName.Text;
                //Proxy.AddNotInOffice(notinoffice);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}