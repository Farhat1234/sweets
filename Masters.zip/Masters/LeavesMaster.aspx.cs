﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Masters
{
    public partial class LeavesMaster : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.LeaveTypes leavetypes;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.LeaveTypes leavetypes;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            leavetypes = new HRMDAL.Entites.LeaveTypes();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                leavetypes.LeaveType = txtLeaveTypeName.Text;
                Proxy.AddLeaveTypes(leavetypes);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}