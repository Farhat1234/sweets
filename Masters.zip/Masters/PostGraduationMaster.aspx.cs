﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Masters
{

    public partial class PostGraduationMaster : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.PostGraduation postgraduation;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.PostGraduation postgraduation;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            postgraduation = new HRMDAL.Entites.PostGraduation();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                postgraduation.PGType = txtPostGraduationName.Text;
                Proxy.AddPostGraduation(postgraduation);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}