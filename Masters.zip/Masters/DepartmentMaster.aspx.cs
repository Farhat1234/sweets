﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Masters
{
    public partial class DepartmentMaster : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.Department department;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.Department department;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            department = new HRMDAL.Entites.Department();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                department.DepartmentType = txtDepartmentName.Text;
                Proxy.AddDepartment(department);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}