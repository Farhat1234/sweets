﻿using BillingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BillingSystem.Controllers
{
    public class CompanyInfoController : Controller
    {
        BillingDataContext db = new BillingDataContext();

        // GET: CompanyInfo
        [HttpGet]
        public ActionResult Index()
        {
            CompanyInfoModel model = new CompanyInfoModel();
            return View(model);
        }

        // GET: CompanyInfo/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: CompanyInfo/Create
        [HttpPost]
        public ActionResult Create(CompanyInfoModel model)
        {
            try
            {
                CompanyInfo entity = new CompanyInfo();
                entity.CompanyName = model.CompanyName;
                entity.CompanyAddress = model.CompanyAddress;
                entity.Email = model.Email;
                entity.Mobile = model.CompanyMobile;
                entity.IsActive = true;
                entity.CreatedOn = DateTime.Now;
                entity.TIN = model.TIN;
                entity.VAT = model.VAT;
                entity.PAN = model.PAN;
                db.CompanyInfos.InsertOnSubmit(entity);
                db.SubmitChanges();
                return RedirectToAction("Details", "Registration");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            
        }

        public ActionResult CompanyDetails()
        {
            IList<CompanyInfoModel> comList = new List<CompanyInfoModel>();
            var details = db.CompanyInfos.ToList();
            foreach (var item in details)
            {
                CompanyInfoModel com = new CompanyInfoModel()
                {
                    Id = item.Id,
                    CompanyName = item.CompanyName,
                    CompanyAddress = item.CompanyAddress,
                    CompanyMobile = item.Mobile,
                    Email = item.Email,
                };
                comList.Add(com);
            }            

            return View(comList.ToList());
        }

        [AcceptVerbs(HttpVerbs.Get | HttpVerbs.Post)]
        public ActionResult Edit(int id)
        {
            try
            {
                var result = db.CompanyInfos.Where(x => x.Id == id).Select(x => new CompanyInfoModel() { CompanyName = x.CompanyName, CompanyMobile = x.Mobile, CompanyAddress = x.CompanyAddress, Email=x.Email }).SingleOrDefault();
                return View(result);
            }
            catch
            {
                throw;
            }
        }

        [HttpPost]
        public ActionResult EditDetails(CompanyInfoModel model)
        {
            CompanyInfo entity = db.CompanyInfos.Where(x => x.Id == model.Id).SingleOrDefault();
            entity.CompanyName = model.CompanyName;
            entity.CompanyAddress = model.CompanyAddress;
            entity.Mobile = model.CompanyMobile;
            db.SubmitChanges();
            return RedirectToAction("Edit",new { id = model.Id});
        }

    }
}
