﻿using BillingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BillingSystem.Controllers
{
    public class ItemController : Controller
    {
        BillingDataContext db = new BillingDataContext();
        // GET: Item
        public ActionResult Index()
        {
            ItemModel model = new ItemModel();
            return View(model);
        }

        // GET: Item/Details/5
        public ActionResult Details()
        {
            IList<ItemModel> itemList = new List<ItemModel>();
            var items = db.ItemMasters.ToList();
            foreach (var item in items)
            {
                ItemModel model = new ItemModel();
                model.Id = item.Id;
                model.ItemName = item.ItemName;
                model.Price = item.Price.Value;
                model.CreatedOn = item.CreatedOn.Value;
                itemList.Add(model);
            }
            return View(itemList);
        }

        [HttpPost]
        public ActionResult AddItem(ItemModel item)
        {
            ItemMaster entity = new ItemMaster();
            entity.ItemName = item.ItemName;
            entity.Price = item.Price;
            entity.CreatedOn = DateTime.Now;
            db.ItemMasters.InsertOnSubmit(entity);
            db.SubmitChanges();
            return RedirectToAction("Details");
        }

        // GET: Item/Edit/5
        public ActionResult Edit(int id)
        {
            var editDetails = db.ItemMasters.Where(x => x.Id == id).Select(x=> new ItemModel() { Id=x.Id,ItemName=x.ItemName,Price=x.Price.Value,CreatedOn=x.CreatedOn.Value}).SingleOrDefault();
            return View(editDetails);
        }

        // POST: Item/Edit/5
        [HttpPost]
        public ActionResult EditDetails(ItemModel model)
        {
            try
            {
                ItemMaster entity = db.ItemMasters.Where(x => x.Id == model.Id).SingleOrDefault();
                entity.ItemName = model.ItemName;
                entity.Price = model.Price;
                entity.ModifiedOn = DateTime.Now;
                db.SubmitChanges();
                return RedirectToAction("Details");
            }
            catch
            {
                return View();
            }
        }

        // GET: Item/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Item/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
