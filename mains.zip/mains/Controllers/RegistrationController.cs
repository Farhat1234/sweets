﻿using BillingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BillingSystem.Controllers
{
    public class RegistrationController : Controller
    {
        BillingDataContext db = new BillingDataContext();

        // GET: Registrartion
        public ActionResult Index()
        {
            RegistrationModel model = new RegistrationModel();
            return View(model);
        }

        // GET: Registrartion/Details/5
        public ActionResult Details()
        {
            return View();
        }

        // POST: Registrartion/Create
        [HttpPost]
        public ActionResult Create(RegistrationModel model)
        {
            try
            {
                UserMaster entity = new UserMaster();
                entity.UserName = model.UserName;
                entity.EmailId = model.EmailId;
                entity.Address = model.Address;
                entity.Mobile = model.Mobile;
                entity.DateOfBirth = model.DOB;
                entity.IsActive = true;
                entity.CreatedBy = model.UserName;
                entity.CreatedOn = DateTime.Now;
                db.UserMasters.InsertOnSubmit(entity);
                db.SubmitChanges();
                return RedirectToAction("LoginView");
            }
            catch
            {
                return View();
            }
        }

        // GET: Registrartion/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Registrartion/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Registrartion/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Registrartion/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        [HttpPost]
        public ActionResult Login(RegistrationModel model)
        {
            try
            {
                var result = db.UserMasters.Select(x => new RegistrationModel() { UserName = x.UserName, Mobile = x.Mobile }).ToList();

                foreach (var item in result)
                {
                    if (item.Mobile == model.Mobile && item.UserName == model.UserName)
                    {
                        return RedirectToAction("Details");
                    }
                    else
                    {
                        //do nothing
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return View();
        }

        [HttpGet]
        public ActionResult LoginView()
        {
            RegistrationModel model = new RegistrationModel();
            return View(model);
        }
    }
}
