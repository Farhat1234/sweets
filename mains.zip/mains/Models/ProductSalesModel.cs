﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BillingSystem.Models
{
    public class ProductSalesModel
    {
        public int Id { get; set; }

        //public List<ItemModel> ItemList { get; set; }

        public double TotalPrice { get; set; }

        public decimal? TotalAmount { get; set; }

        public string ItemName { get; set; }

        public int Quantity { get; set; }

        public int BillNo { get; set; }

        public DateTime BillDate { get; set; }

        public string UserName { get; set; }

        public string CustomerName { get; set; }

        public string CustomerMobile { get; set; }

        //public List<RegistrationModel> UserList { get; set; }

        // public List<CustomerModel> CustomerList { get; set; }
    }
}