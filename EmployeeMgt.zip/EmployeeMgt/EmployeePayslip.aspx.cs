﻿using HRMWcfService1.Utilities;
using Novacode;
using System;
using System.Data;
using System.IO;
using System.Web;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeePayslip : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.PaySlip Payslip;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.PaySlip Payslip;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Payslip = new HRMDAL.Entites.PaySlip();

            int empid = Convert.ToInt32(Request.QueryString["Empid"]);

            DataSet ds = new DataSet();
            ds = Proxy.GetPayslipDetails(empid);
            grdPaySlip.DataSource = ds;
            grdPaySlip.DataBind();
        }

        protected void lbtnDownload_Click(object sender, EventArgs e)
        {
            try
            {
                string fileExtension = null;
                string filePath = Server.MapPath("~/Template/payslip.docx");
                //string filePath = @"D:\HRMS\HRMS\HumanResourceApplication bk\HumanResourceApplication\HumanResourceApplication\Template\payslip.docx";
                fileExtension = Path.GetExtension(filePath).Replace(".", "");
                string filename = Path.GetFileName(filePath).Replace(Path.GetExtension(filePath), "");
                int empID = Convert.ToInt32(Request.QueryString["Empid"]);

                decimal grossPay = Proxy.GetEmployeeGross(empID);
                double basic = Utility.CalculateBasicOfGross(Convert.ToDouble(grossPay));
                decimal hra = Utility.CalculateHRAfromBasic(Convert.ToDecimal(basic));
                decimal sa = Utility.CalculateSA(Convert.ToDecimal(basic), hra, grossPay);
                decimal cpf = Utility.CalculateCPF(Convert.ToDecimal(basic));
                decimal ewf = Utility.CalculateEWF(grossPay);
                decimal esi = Convert.ToDecimal(Utility.CalculateESI(Convert.ToInt32(grossPay)));
                decimal earnings = Utility.Earnings(Convert.ToDecimal(basic), hra, sa);
                decimal deductions = Utility.Deductions(cpf, ewf, esi);
                decimal salary = earnings - deductions;
                int cea = Proxy.GetEmployeeChildCount(empID);

                DataSet result = Proxy.GetEmployeeDetailsPayslip(empID);

                using (DocX doc = DocX.Load(filePath))
                {
                    using (DocX xCopy = doc.Copy())
                    {
                        xCopy.ReplaceText("<<Date>>", DateTime.Now.ToString("MMMM"));
                        xCopy.ReplaceText("<<empID>>", empID.ToString());
                        xCopy.ReplaceText("<<Name>>", result.Tables[0].Rows[0][1].ToString());
                        xCopy.ReplaceText("<<designation>>", "Executive");
                        xCopy.ReplaceText("<<pan>>", result.Tables[0].Rows[0][3].ToString());
                        xCopy.ReplaceText("<<doj>>", result.Tables[0].Rows[0][2].ToString());
                        xCopy.ReplaceText("<<basic>>", basic.ToString());
                        xCopy.ReplaceText("<<HRA>>", hra.ToString());
                        xCopy.ReplaceText("<<CCA>>", "1600");
                        xCopy.ReplaceText("<<MA>>", "1250");
                        xCopy.ReplaceText("<<SA>>", sa.ToString());
                        xCopy.ReplaceText("<<CPF>>", cpf.ToString());
                        xCopy.ReplaceText("<<CEA>>", cea.ToString());
                        xCopy.ReplaceText("<<ESI>>", esi.ToString());
                        xCopy.ReplaceText("<<LW>>", "10");
                        xCopy.ReplaceText("<<EWF>>", ewf.ToString());
                        xCopy.ReplaceText("<<Earnings>>", earnings.ToString());
                        xCopy.ReplaceText("<<Deductions>>", deductions.ToString());
                        xCopy.ReplaceText("<<Salary>>", salary.ToString());
                        xCopy.ReplaceText("<<DOB>>", result.Tables[0].Rows[0][5].ToString());
                        xCopy.ReplaceText("<<UAN>>", result.Tables[0].Rows[0][4].ToString());

                        MemoryStream ms = new MemoryStream();
                        ms.Position = 0;
                        xCopy.SaveAs(ms);

                        HttpContext.Current.Response.Clear();
                        System.Web.HttpContext.Current.Response.ClearContent();
                        HttpContext.Current.Response.ContentType = "application/msword";
                        HttpContext.Current.Response.AddHeader("Content-Disposition", "attachment; filename=\"" + filename + ".docx\"");
                        HttpContext.Current.Response.BinaryWrite(ms.ToArray());

                        // FileAttributes attributes = File.GetAttributes(filePath);
                        // File.SetAttributes(filePath, File.GetAttributes(filePath) | FileAttributes.ReadOnly);
                    }
                }

            }
            catch
            {
                throw;
            }
            finally
            {
                System.Web.HttpContext.Current.Response.End();
                System.Web.HttpContext.Current.Response.Flush();
            }
        }
    }
}