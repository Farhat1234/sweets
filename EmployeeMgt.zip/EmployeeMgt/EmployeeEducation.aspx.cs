﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeEducation : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.Education education;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.Education education;

        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["HumanResourceConnectionString"].ConnectionString);

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            education = new HRMDAL.Entites.Education();

            bool value = Proxy.GetEducationDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (value)
            {
                DataSet ds = Proxy.GetEducationById(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdEducationDetails.DataSource = ds;
                grdEducationDetails.DataBind();
                grdEducationDetails.Visible = true;
                pnlEducation.Visible = false;
                btnUpdate1.Visible = true;
                btnSubmit.Visible = false;

            }
            else
            {
                // do nothing
            }
            btnEditEducatinDetails.Visible = true;
           // btnUpdate1.Visible = false;

            if (!IsPostBack)
            {
                //Call countries DropDownList on page load event
                BindCountriesDropDownList();
            }
        }

        protected void BindCountriesDropDownList()
        {
            try
            {
                SqlDataAdapter adp = new SqlDataAdapter("select * from CountryMaster", con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                ddlCountry.DataSource = ds;
                ddlCountry.DataTextField = "CountryName";
                ddlCountry.DataValueField = "CountryID";
                ddlCountry.DataBind();
                ddlCountry.Items.Insert(0, new ListItem("-- Select Country --", "0"));
                ddlState.Items.Insert(0, new ListItem("-- Select State --", "0"));
                ddlCity.Items.Insert(0, new ListItem("-- Select City --", "0"));
            }
            catch (Exception ex)
            {
                Response.Write("Error occured : " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                education.EmpId = Convert.ToInt32(Request.QueryString["EmpId"]);
                education.StartDate = Convert.ToDateTime(txtFromDate.Text);
                education.EndDate = Convert.ToDateTime(txtToDate.Text);
                education.Certificate = ddlCertificate.SelectedItem.Text;
                education.BranchStudyOne = ddlBranchOfStudy.SelectedItem.Text;
                education.NameOfInstitute = txtNameOfInstitute.Text;
                education.Qualification = ddlQualification.SelectedItem.Text;
                education.Type = ddlType.SelectedItem.Text;
                education.EducationalEstimation = txtEducationalEst.Text;
                education.Duration = Convert.ToDecimal(txtDurationOfCourse.Text);
                education.City = ddlCity.SelectedItem.Text;
                education.Grade = txtGrade.Text;
                education.AdditionalCourse = txtAdditionalCourse.Text;
                Proxy.AddEducationDetails(education);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
                
                pnlEducation.Visible = false;
                btnSubmit.Visible = false;
                btnUpdate1.Visible = true;
                grdEducationDetails.Visible = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void ddlState_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int StateId = Convert.ToInt32(ddlState.SelectedValue);
                //Select all Cities corresponding to the selected State
                SqlDataAdapter adp = new SqlDataAdapter("select * from CityMaster where StateID=" + StateId, con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                ddlCity.DataSource = ds;
                ddlCity.DataTextField = "CityName";
                ddlCity.DataValueField = "CityID";
                ddlCity.DataBind();
                ddlCity.Items.Insert(0, new ListItem("-- Select City --", "0"));
            }
            catch (Exception ex)
            {
                Response.Write("Error occured : " + ex.Message.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        protected void ddlCountry_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int CountryId = Convert.ToInt32(ddlCountry.SelectedValue);
                //Select all States corresponding to the selected Country
                SqlDataAdapter adp = new SqlDataAdapter("Select * from StateMaster where CountryID=" + CountryId, con);
                DataSet ds = new DataSet();
                adp.Fill(ds);
                ddlState.DataSource = ds;
                ddlState.DataTextField = "StateName";
                ddlState.DataValueField = "StateID";
                ddlState.DataBind();
                ddlState.Items.Insert(0, new ListItem("-- Select State --", "0"));
                //If State is not selected then clear City DropDownList also
                if (ddlState.SelectedValue == "0")
                {
                    ddlCity.Items.Clear();
                    ddlCity.Items.Insert(0, new ListItem("-- Select City --", "0"));
                }
            }
            catch (Exception ex)
            {
                //Printing any exception if occcured.
                Response.Write("Error occured: " + ex.Message.ToString());
            }
            finally
            {
                //Close the connection
                con.Close();
            }
        }

        //private void BindDoctorate()
        //{
        //    try
        //    {
        //        SqlDataAdapter adp = new SqlDataAdapter("select * from DoctorateMaster", con);
        //        DataSet ds = new DataSet();
        //        adp.Fill(ds);
        //        ddlQualification.DataSource = ds;
        //        ddlQualification.DataTextField = "DoctorateType";
        //        ddlQualification.DataValueField = "DoctorateID";
        //        ddlQualification.DataBind();
        //        ddlQualification.Items.Insert(0, new ListItem("-- Select Qualification --", "0"));
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write("Error occured : " + ex.Message.ToString());
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

        //private void BindPostGraduation()
        //{
        //    try
        //    {
        //        SqlDataAdapter adp = new SqlDataAdapter("select * from PGMaster", con);
        //        DataSet ds = new DataSet();
        //        adp.Fill(ds);
        //        ddlQualification.DataSource = ds;
        //        ddlQualification.DataTextField = "PGType";
        //        ddlQualification.DataValueField = "PGID";
        //        ddlQualification.DataBind();
        //        ddlQualification.Items.Insert(0, new ListItem("-- Select Qualification --", "0"));
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write("Error occured : " + ex.Message.ToString());
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

        //private void BindGraduation()
        //{
        //    try
        //    {
        //        SqlDataAdapter adp = new SqlDataAdapter("select * from GraduationMaster", con);
        //        DataSet ds = new DataSet();
        //        adp.Fill(ds);
        //        ddlQualification.DataSource = ds;
        //        ddlQualification.DataTextField = "DegreeType";
        //        ddlQualification.DataValueField = "DegreeID";
        //        ddlQualification.DataBind();
        //        ddlQualification.Items.Insert(0, new ListItem("-- Select Qualification --", "0"));
        //    }
        //    catch (Exception ex)
        //    {
        //        Response.Write("Error occured : " + ex.Message.ToString());
        //    }
        //    finally
        //    {
        //        con.Close();
        //    }
        //}

        //protected void ddlCertificate_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    if (ddlCertificate.SelectedItem.Value == "Graduation")
        //    {
        //        BindGraduation();
        //    }
        //    else if (ddlCertificate.SelectedItem.Value == "Post Graduation")
        //    {
        //        BindPostGraduation();
        //    }
        //    else if (ddlCertificate.SelectedItem.Value == "Doctorate")
        //    {
        //        BindDoctorate();
        //    }
        //    else
        //    {
        //        ddlQualification.Items.Clear();
        //    }
        //}

        protected void btnEditEducatinDetails_Click(object sender, EventArgs e)
        {
            grdEducationDetails.Visible = false;
            btnEditEducatinDetails.Visible = false;
            pnlEducation.Visible = true;
            bool value = Proxy.GetEducationDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));
            if (value)
            {
                GetEducationDetails(Convert.ToInt32(Request.QueryString["EmpId"]));
                //GetVisibilty();
            }
            ddlCountry.Enabled = false;
            ddlCity.Enabled = false;
            ddlState.Enabled = false;
           
            ddlCertificate.Enabled = false;
           
        }

        public void GetEducationDetails(int empid)
        {
            DataSet ds = new DataSet();
            ds = Proxy.GetEducationById(empid);


            txtAdditionalCourse.Text = ds.Tables[0].Rows[0][15].ToString();
            txtDurationOfCourse.Text = ds.Tables[0].Rows[0][14].ToString();
            txtEducationalEst.Text = ds.Tables[0].Rows[0][13].ToString();
            txtFromDate.Text = ds.Tables[0].Rows[0][2].ToString();
            txtGrade.Text = ds.Tables[0].Rows[0][11].ToString();
            txtNameOfInstitute.Text = ds.Tables[0].Rows[0][7].ToString();
            txtToDate.Text = ds.Tables[0].Rows[0][3].ToString();
            ddlBranchOfStudy.SelectedItem.Text = ds.Tables[0].Rows[0][6].ToString();
            ddlCertificate.SelectedItem.Text = ds.Tables[0].Rows[0][4].ToString();
            ddlCity.SelectedItem.Text = ds.Tables[0].Rows[0][9].ToString();
            ddlCountry.SelectedItem.Text = ds.Tables[0].Rows[0][8].ToString();
            //ddlQualification.SelectedItem.Text = ds.Tables[0].Rows[0][5].ToString();
           // ddlState.SelectedValue = ds.Tables[0].Rows[0][11].ToString();
            ddlType.SelectedItem.Text = ds.Tables[0].Rows[0][10].ToString();

            btnEditEducatinDetails.Visible = false;
        }
    }
}