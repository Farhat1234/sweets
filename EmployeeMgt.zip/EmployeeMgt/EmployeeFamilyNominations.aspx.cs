﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeFamilyNominations : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.FamilyNomination familyNomination;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.FamilyNomination familyNomination;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            familyNomination = new HRMDAL.Entites.FamilyNomination();

            bool value = Proxy.GetEmployeeNominationDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (value)
            {
                DataSet ds = Proxy.GetFamilyNomination(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdFamilyNominations.DataSource = ds;
                grdFamilyNominations.DataBind();
                grdFamilyNominations.Visible = true;
                pnlFamilyNominations.Visible = false;
            }
            else
            {
                // do nothing
            }
           
        }

        protected void grdFamilyNominations_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            grdFamilyNominations.EditIndex = -1;
            DataSet ds = Proxy.GetFamilyNomination(Convert.ToInt32(Request.QueryString["EmpId"]));
            grdFamilyNominations.DataSource = ds;
            grdFamilyNominations.DataBind();
        }

        protected void grdFamilyNominations_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void grdFamilyNominations_RowEditing(object sender, GridViewEditEventArgs e)
        {
            grdFamilyNominations.EditIndex = e.NewEditIndex;
            DataSet ds = Proxy.GetFamilyNomination(Convert.ToInt32(Request.QueryString["EmpId"]));
            grdFamilyNominations.DataSource = ds;
            grdFamilyNominations.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                familyNomination.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                familyNomination.Relation = drpRelation.SelectedItem.Text;
                familyNomination.Gender = ddlGender.SelectedItem.Text;
                familyNomination.FirstName = txtFName.Text;
                familyNomination.LastName = txtLName.Text;
                familyNomination.Initials = txtInitials.Text;
                familyNomination.NameatBirth = txtNameatBirth.Text;
                familyNomination.DateofBirth = Convert.ToDateTime(txtDOB.Text);
                familyNomination.PlaceofBirth = txtBirthPlace.Text;
                familyNomination.BirthCountry = txtBirthCountry.Text;
                familyNomination.Nationality = txtNationality.Text;
                Proxy.FamilyNomination(familyNomination);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);

                DataSet ds = Proxy.GetFamilyNomination(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdFamilyNominations.DataSource = ds;
                grdFamilyNominations.DataBind();
                grdFamilyNominations.Visible = true;
            }
            catch (Exception ex)
            {                
                throw ex;
            }            
        }

        protected void btnAddNewNomination_Click(object sender, EventArgs e)
        {
            grdFamilyNominations.Visible = false;
            pnlFamilyNominations.Visible = true;
            btnAddNewNomination.Visible = false;
        }
    }
}