﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeIDProof : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.IDProof Idproof;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.IDProof Idproof;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Idproof = new HRMDAL.Entites.IDProof();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Idproof.PAN = txtPAN.Text;
                Idproof.PRAN = txtPRAN.Text;
                Idproof.Aadhar = txtAadhaar.Text;
                Idproof.UAN = txtUAN.Text;
                Idproof.DrivingLicense = txtDriving.Text;
                Idproof.ESIC = txtESIC.Text;
                Idproof.VoterID = txtVoters.Text;
                Idproof.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                Proxy.AddIDProof(Idproof);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {                
                throw ex;
            }        
        }           
       
    }
}