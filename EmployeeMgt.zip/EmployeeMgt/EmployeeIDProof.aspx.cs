﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeIDProof : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.IDProof Idproof;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.IDProof Idproof;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Idproof = new HRMDAL.Entites.IDProof();

            DataSet value = Proxy.GetIDProofDetails(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (!IsPostBack)
            {
                txtPAN.Text=value.Tables[0].Rows[0][2].ToString();
                txtPRAN.Text=value.Tables[0].Rows[0][3].ToString();
                txtUAN.Text=value.Tables[0].Rows[0][4].ToString();
                txtESIC.Text=value.Tables[0].Rows[0][6].ToString();
                txtDriving.Text=value.Tables[0].Rows[0][5].ToString();
                txtAadhaar.Text=value.Tables[0].Rows[0][1].ToString();
                txtVoters.Text=value.Tables[0].Rows[0][7].ToString();
            }
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Idproof.PAN = txtPAN.Text;
                Idproof.PRAN = txtPRAN.Text;
                Idproof.Aadhar = txtAadhaar.Text;
                Idproof.UAN = txtUAN.Text;
                Idproof.DrivingLicense = txtDriving.Text;
                Idproof.ESIC = txtESIC.Text;
                Idproof.VoterID = txtVoters.Text;
                Idproof.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                Proxy.AddIDProof(Idproof);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}