﻿using HumanResourceApplication.HRMRef;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using HRMWcfService1.Utilities;


namespace HumanResourceApplication.EmployeeMgt
{
    public partial class EmployeeBankDetails : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
        //HRMRef.BankDetails Bank;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.BankDetails Bank;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Bank = new HRMDAL.Entites.BankDetails();

            bool value = Proxy.GetBankDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));

            if (value)
            {
                DataSet ds = Proxy.GetBankById(Convert.ToInt32(Request.QueryString["EmpId"]));
                grdBankDetails.DataSource = ds;
                grdBankDetails.DataBind();
                grdBankDetails.Visible = true;
                pnlForm.Visible = false;
                btnUpdate.Visible = true;
                btnSubmit.Visible = false;

            }
            else
            {
                // do nothing
            }
            btnAddNewBank.Visible = true;
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Bank.EmpId = Convert.ToInt32(Request.QueryString["EmpId"]);
                Bank.AccountType = txtAccType.Text;
                Bank.AccountNo = Convert.ToInt32(txtAccNo.Text);
                Bank.AccountHolderName = txtAccHolder.Text;
                Bank.BankName = txtBankName.Text;
                Bank.Branch = txtBranch.Text;
                Bank.Country = txtSCountry.Text;
                Bank.IFSC = txtSIFSC.Text;
                Bank.RAccountType = txtRAccType.Text;
                Bank.ReimburseAccHolder = txtRAccHolder.Text;
                Bank.RAccountNo = Convert.ToInt64(txtRAccNo.Text);
                Bank.RBankName = txtRBankName.Text;
                Bank.ReimburseBranch = txtRBranch.Text;
                Bank.RCountry = txtRCountry.Text;
                Bank.RIFSC = txtRIFSC.Text;
                Proxy.AddBankDetails(Bank);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
                Clear();
                pnlForm.Visible = false;
                btnSubmit.Visible = false;
                btnUpdate.Visible = true;
                grdBankDetails.Visible = true;
                
            }
            catch (Exception ex)
            {                
                throw ex;
            }            
        }

        public void Clear()
        {
            txtAccNo.Text = "";
            txtBankName.Text = "";
            txtAccHolder.Text = "";
            txtBranch.Text = "";
            txtSIFSC.Text = "";
            txtSCountry.Text = "";
            txtRAccNo.Text = "";
            txtRAccHolder.Text = "";
            txtRBankName.Text = "";
            txtRBranch.Text = "";
            txtRCountry.Text = "";
            txtRIFSC.Text = "";
        }

        //protected void btnUpdate_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        pnlForm.Visible = true;
        //        btnSubmit.Visible = true;
        //        btnUpdate.Visible = false;
        //        grdBankDetails.Visible = false;
              
        //        List<BankDetails> bank = new List<BankDetails>();
        //        bank = Proxy.UpdateBankById(Convert.ToInt32(Request.QueryString["EmpId"]));

        //        foreach (var item in bank)
        //        {
        //           // txtAccNo.Text = item.AccountNo;
        //            //txtBankName.Text = item.BankName;
        //           // txtSCountry.Text = item.Country;
        //           // txtSIFSC.Text = item.IFSC;
        //           // txtRAccNo.Text = item.RAccountNo;
        //           // txtRBankName.Text = item.RBankName;
        //            //txtRCountry.Text = item.RCountry;
        //            //txtRIFSC.Text = item.RIFSC;
        //        }
        //    }
        //    catch (Exception ex)
        //    {                
        //        throw ex;
        //    }            
        //}

        protected void btnAddNewBank_Click(object sender, EventArgs e)
        {
            grdBankDetails.Visible = false;
            btnAddNewBank.Visible = false;
            pnlForm.Visible = true;
            bool value = Proxy.GetBankDetailsById(Convert.ToInt32(Request.QueryString["EmpId"]));
            if (value)
            {
                GetBankDetails(Convert.ToInt32(Request.QueryString["EmpId"]));
                //GetVisibilty();
            }
        }

        public void GetBankDetails(int empid)
        {
            DataSet ds = new DataSet();
            ds = Proxy.GetBankById(empid);

            txtAccNo.Text = ds.Tables[0].Rows[0][4].ToString();
            txtAccHolder.Text = ds.Tables[0].Rows[0][13].ToString();
            txtBankName.Text = ds.Tables[0].Rows[0][3].ToString();
            txtBranch.Text = ds.Tables[0].Rows[0][14].ToString();
            txtSCountry.Text = ds.Tables[0].Rows[0][5].ToString();
            txtSIFSC.Text = ds.Tables[0].Rows[0][6].ToString();
            txtRAccHolder.Text = ds.Tables[0].Rows[0][15].ToString();
            txtRAccNo.Text = ds.Tables[0].Rows[0][9].ToString();
            txtRBankName.Text = ds.Tables[0].Rows[0][8].ToString();
            txtRBranch.Text = ds.Tables[0].Rows[0][14].ToString();
            txtRCountry.Text = ds.Tables[0].Rows[0][10].ToString();
            txtRIFSC.Text = ds.Tables[0].Rows[0][11].ToString();

            btnAddNewBank.Visible = false;
        }
    }
}