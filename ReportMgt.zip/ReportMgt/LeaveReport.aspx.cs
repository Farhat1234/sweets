﻿using Microsoft.Reporting.WebForms;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.ReportMgt
{
    public partial class LeaveReport : System.Web.UI.Page
    {
        HRMBAL.BALService Proxy;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();

            if (!IsPostBack)
            {
                ddlEmpId.DataSource = Proxy.GetIDEmployeeRegistration();
                ddlEmpId.DataTextField = "EmpId";
                ddlEmpId.DataValueField = "EmpId";
                ddlEmpId.DataBind();
            }
        }

        private void GetData(int empid)
        {
            try
            {
                string conString = ConfigurationManager.ConnectionStrings["HumanResourceConnectionString"].ConnectionString;
                string query = "select *, lm.LeaveType as LeaveType from ApplyLeave al inner join LeaveTypeMaster lm on lm.LeaveID = Cast(al.LeaveTypeID as int) where EmpID= '" + empid + "'";

                using (SqlConnection con = new SqlConnection(conString))
                {
                    con.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(query, con))
                    {
                        da.SelectCommand.Connection = con;

                        DataSet ds = new DataSet();
                        da.Fill(ds);
                        grdLeave.DataSource = ds;
                        grdLeave.DataBind();
                    }
                }
            }
            catch
            {
                throw;
            }

        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            GetData(Convert.ToInt32(ddlEmpId.SelectedItem.Text));
        }

        protected void btnExport_Click(object sender, EventArgs e)
        {
            Response.ClearContent();
            Response.AppendHeader("content-disposition", "attachment; filename=Leaves.xls");
            Response.ContentType = "application/excel";
            System.IO.StringWriter stringWriter = new System.IO.StringWriter();
            HtmlTextWriter htw = new HtmlTextWriter(stringWriter);

            grdLeave.HeaderRow.Style.Add("background-color", "#FFFFFF");

            foreach (TableCell tableCell in grdLeave.HeaderRow.Cells)
            {
                tableCell.Style["background-color"] = "#A55129";
            }

            foreach (GridViewRow gridViewRow in grdLeave.Rows)
            {
                gridViewRow.BackColor = System.Drawing.Color.White;
                foreach (TableCell gridViewRowTableCell in gridViewRow.Cells)
                {
                    gridViewRowTableCell.Style["background-color"] = "#FFF7E7";
                }
            }

            grdLeave.RenderControl(htw);
            Response.Write(stringWriter.ToString());
            Response.End();
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
        }
    }
}