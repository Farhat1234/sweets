﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;

namespace HumanResourceApplication.Leave_Mgt
{
    public partial class LeaveQuota : System.Web.UI.Page
    {
        HRMBAL.BALService Proxy;
        HRMDAL.Entites.ApplyLeave Apply;   

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Apply = new HRMDAL.Entites.ApplyLeave();

            Apply.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);

            DataSet bindingDs = Proxy.GetLeaveQuota();
            grdLeave.DataSource = bindingDs;
            grdLeave.DataBind();
         }
    }
}