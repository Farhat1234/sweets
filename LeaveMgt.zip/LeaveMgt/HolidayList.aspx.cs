﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.LeaveMgt
{
    public partial class HolidayList : System.Web.UI.Page
    {
        HRMBAL.BALService Proxy;
       // HRMDAL.Entites.HolidayList Holiday;

        protected void Page_Load(object sender, EventArgs e)
        {
           // Holiday = new ServiceReference1.HolidayList();
            Proxy = new HRMBAL.BALService();
        }

        //protected void btnSubmit_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        Holiday.Name = txtHolidayName.Text;
        //        Holiday.Date = Convert.ToDateTime(txtHolidayDate.Text);
        //        Holiday.Day = txtDay.Text;
        //        Holiday.Description = txtDescription.Text;
        //        Proxy.HolidayList(Holiday);
        //        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

    }
}