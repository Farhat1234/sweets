﻿using HRMWcfService1.Utilities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Leave_Mgt
{
    public partial class ApplyLeave : System.Web.UI.Page
    {
        //ServiceReference1.ApplyLeaveClient Proxy;
        //ServiceReference1.ApplyLeave Apply;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.ApplyLeave Apply;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            Apply = new HRMDAL.Entites.ApplyLeave();

            drpLeaveType.DataSource = Proxy.GetLeaveTypes();
            drpLeaveType.DataTextField = "LeaveType";
            drpLeaveType.DataValueField = "LeaveID";
            ListItem leavetype = new ListItem();
            leavetype.Text = "--- Select Leave Type ---";
            leavetype.Value = "-1";
            drpLeaveType.AppendDataBoundItems = true;
            drpLeaveType.Items.Add(leavetype);
            drpLeaveType.DataBind();

        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            Apply.FromDate = Convert.ToDateTime(TbFromDte.Text);
            Apply.Todate = Convert.ToDateTime(TbToDate.Text);
            TimeSpan noOfDays = (Apply.Todate - Apply.FromDate);
            Apply.NofDays = noOfDays.Days;
            TbNofDys.Text = noOfDays.Days.ToString();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Apply.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                Apply.FromDate = Convert.ToDateTime(TbFromDte.Text);
                Apply.Todate = Convert.ToDateTime(TbToDate.Text);
                Apply.NofDays = int.Parse(TbNofDys.Text);
                Apply.Reason = TbReson.Text;
                Apply.LeaveTypeID = Convert.ToInt32(drpLeaveType.SelectedValue);
                Proxy.ApplyLeav(Apply);
                ClearFields();
                Utility.SendMail("sydmuzakir@gmail.com", "ajrekarfarhat@gmail.com", null, "hi", "hello world");
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Leave applied Successfully')", true);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ClearFields()
        {
            TbFromDte.Text = string.Empty;
            TbToDate.Text = string.Empty;
            TbNofDys.Text = string.Empty;
            TbReson.Text = string.Empty;
            drpLeaveType.SelectedValue = "-1";
        }

        protected void CalendarExtender1_DayRender(object sender, DayRenderEventArgs e)
        {
            string store = e.Day.DayNumberText;
            
            if (e.Day.IsWeekend)
            {
                e.Day.IsSelectable = false;
            }

        }
    }
}