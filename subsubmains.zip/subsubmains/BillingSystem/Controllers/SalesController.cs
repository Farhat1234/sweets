﻿using BillingSystem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BillingSystem.Controllers
{
    public class SalesController : Controller
    {
        BillingDataContext db = new BillingDataContext();

        // GET: Sales
        public ActionResult Index()
        {
            BillingDataContext db = new BillingDataContext();
            ViewBag.Products = new SelectList(db.ItemMasters, "Id", "ItemName");
            CustomerModel model = new CustomerModel();
            return View(model);
        }

        [HttpGet]
        public ActionResult Views()
        {
            ViewBag.Products = new SelectList(db.ItemMasters, "Id", "ItemName");
            return View();
        }


        // GET: Sales/Details/5
        [HttpPost]
        public ActionResult ViewDetails(FormCollection form)
        {
            try
            {
                ViewBag.Products = new SelectList(db.ItemMasters, "Id", "ItemName");
                ProductSale entity = new ProductSale();
                entity.ItemId = Convert.ToInt32(form["Products"]);
                var mobile = db.CustomerDetails.OrderByDescending(x=>x.Id).Select(s=>s.CustomerMobile).FirstOrDefault();
                int customerid = db.CustomerDetails.Where(x => x.CustomerMobile == mobile).Select(x => x.Id).FirstOrDefault();
                Random val = new Random();
                var price = db.ItemMasters.Where(x => x.Id == entity.ItemId).Select(x => x.Price).SingleOrDefault();
                entity.Quantity = Convert.ToInt32(form["Quantity"]);
                entity.BillDate = DateTime.Now;
                entity.BillNo = val.Next();
                entity.CustomerId = customerid;
                db.ProductSales.InsertOnSubmit(entity);
                db.SubmitChanges();
                ViewData["Data"] = db.ProductSales.Where(x => x.CustomerId == customerid).Select(x => new ProductSalesModel() { Quantity = x.Quantity.Value, ItemName = x.ItemMaster.ItemName,TotalAmount=(x.ItemMaster.Price * x.Quantity.Value) }).ToList();
                return View("Views");
            }
            catch
            {
                throw;
            }
        }

        // GET: Sales/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Sales/Create
        [HttpPost]
        public ActionResult Create(FormCollection form)
        {
            try
            {
                CustomerDetail customer = new CustomerDetail();
                customer.CustomerName = form["CustomerName"];
                customer.CustomerMobile = form["CustomerMobile"];
                db.CustomerDetails.InsertOnSubmit(customer);
                db.SubmitChanges();
                return RedirectToAction("Views");
            }
            catch
            {
                throw;
            }
        }

        // GET: Sales/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Sales/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        // GET: Sales/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Sales/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
