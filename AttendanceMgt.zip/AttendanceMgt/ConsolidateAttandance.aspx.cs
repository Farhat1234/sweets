﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Attendance_Mgt
{
    public partial class ConsolidateAttandance : System.Web.UI.Page
    {
        //DailyAttend.DailyAttendanceClient Proxy;
        //DailyAttend.DailyAttendance GetRecord;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.DailyAttendance GetRecord;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            GetRecord = new HRMDAL.Entites.DailyAttendance();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DataSet ds = Proxy.GetAttendanceRecord(Convert.ToInt32(Request.QueryString["EmpId"]), Convert.ToDateTime(txtFromDate.Text), Convert.ToDateTime(txtToDate.Text));
            grdConsolidate.DataSource = ds;
            grdConsolidate.DataBind();
        }
    }
}