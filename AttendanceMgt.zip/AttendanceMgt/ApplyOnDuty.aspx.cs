﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Attendance_Mgt
{
    public partial class ApplyOnDuty : System.Web.UI.Page
    {
        //DailyAttend.DailyAttendanceClient Proxy;
        //DailyAttend.ApplyOnDuty onDuty;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.ApplyOnDuty onDuty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            onDuty = new HRMDAL.Entites.ApplyOnDuty();

            txtApproverName.Text = Proxy.GetApproverByID(Convert.ToInt32(Request.QueryString["EmpId"]));

            ddlNIO.DataSource = Proxy.GetNIOCategory();
            ddlNIO.DataTextField = "NIOType";
            ddlNIO.DataValueField = "NIOType";
            ListItem nio = new ListItem();
            nio.Text = "--- Select Not In Office Category ---";
            nio.Value = "-1";
            ddlNIO.AppendDataBoundItems = true;
            ddlNIO.Items.Add(nio);
            ddlNIO.DataBind();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                onDuty.EmpID = Convert.ToInt32(Request.QueryString["EmpId"]);
                onDuty.TypeOf = ddlNIO.SelectedItem.Text;
                onDuty.FromDate = Convert.ToDateTime(txtFromDate.Text);
                onDuty.ToDate = Convert.ToDateTime(txtToDate.Text);
                onDuty.RmID = txtApproverName.Text; 
                onDuty.Reason = txtComments.Text;
                Proxy.OnDutyApply(onDuty);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);
                ClearFields();
            }
            catch (Exception ex)
            {                
                throw ex;
            }           
        }

        protected void btnCalculate_Click(object sender, EventArgs e)
        {
            onDuty.FromDate = Convert.ToDateTime(txtFromDate.Text);
            onDuty.ToDate = Convert.ToDateTime(txtToDate.Text);
            TimeSpan noOfDays = (onDuty.ToDate - onDuty.FromDate);
            txtTDays.Text = noOfDays.Days.ToString();
        }

        public void ClearFields()
        {
            txtToDate.Text = string.Empty;
            txtApproverName.Text = string.Empty;
            txtTDays.Text = string.Empty;
            txtComments.Text = string.Empty;
            ddlNIO.SelectedIndex = -1;
            txtFromDate.Text = string.Empty;
        }
    }
}