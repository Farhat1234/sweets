﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Web.UI;

namespace HumanResourceApplication.Attendance_Mgt
{
    public partial class ApplyAttendance : System.Web.UI.Page
    {
        //DailyAttend.DailyAttendanceClient Proxy;
        //DailyAttend.DailyAttendance attendance;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.DailyAttendance attendance;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            attendance = new HRMDAL.Entites.DailyAttendance();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                DataSet ds = GetDataSet();
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Record Inserted Successfully')", true);

            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        private DataSet GetDataSet()
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string result = string.Empty;
            try
            {
                try
                {
                    string path = flpAttendanceSheet.PostedFile.FileName;
                    string filePath = Server.MapPath("~/Template/" + flpAttendanceSheet.FileName);
                    flpAttendanceSheet.PostedFile.SaveAs(filePath);
                    if (File.Exists(filePath))
                    {
                        string excelConnectionString = string.Format("Provider=Microsoft.Jet.OLEDB.4.0;Data Source={0};Extended Properties=Excel 8.0;", filePath);
                        excelConnectionString = String.Format(excelConnectionString, filePath);

                        using (OleDbConnection excelConnection = new OleDbConnection(excelConnectionString))
                        {
                            excelConnection.Open();
                            OleDbCommand cmd = new OleDbCommand(@"Select * from [Sheet3$]", excelConnection);
                            OleDbDataAdapter oleda = new OleDbDataAdapter(cmd);
                            oleda.Fill(ds);

                            dt = ds.Tables[0];

                            using (SqlBulkCopy bulk = new SqlBulkCopy(System.Configuration.ConfigurationManager.ConnectionStrings["HumanResourceConnectionString"].ConnectionString))
                            {
                                bulk.DestinationTableName = "AttendanceDetails";
                                bulk.ColumnMappings.Add("f1", "f1");
                                bulk.ColumnMappings.Add("f2", "f2");
                                bulk.ColumnMappings.Add("f3", "f3");
                                bulk.ColumnMappings.Add("f4", "f4");
                                bulk.ColumnMappings.Add("f5", "f5");
                                bulk.ColumnMappings.Add("f19", "f19");
                                bulk.WriteToServer(dt);
                            }

                            //grdAttendance.DataSource = ds;
                            //grdAttendance.DataBind();                            

                        }
                        //To delete the copied XL file from BudgetUpload folder
                        //File.Delete(filePath);
                    }
                    else
                    {
                        ScriptManager.RegisterStartupScript(Page, GetType(), "showalert5", "EnableErrorMessage('FileName already exist, please modify your file name and upload again.');", true);
                    }
                    return ds;

                }
                catch (OleDbException oldEx)
                {
                    throw oldEx;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void BindGridAttendance()
        {

        }
    }
}