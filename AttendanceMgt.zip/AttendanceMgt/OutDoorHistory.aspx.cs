﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.AttendanceMgt
{
    public partial class OutDoorHistory : System.Web.UI.Page
    {
        //DailyAttend.DailyAttendanceClient Proxy;
        //DailyAttend.ApplyOnDuty onDuty;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.ApplyOnDuty onDuty;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            onDuty = new HRMDAL.Entites.ApplyOnDuty();

            DataSet ds = Proxy.GetOnDutyHistory(Convert.ToInt32(Request.QueryString["EmpId"]));
            //DataSet ds = Proxy.GetOnDutyHistory(1030205);

            grdOnDutyHistory.DataSource = ds;
            grdOnDutyHistory.DataBind();

        }
    }
}