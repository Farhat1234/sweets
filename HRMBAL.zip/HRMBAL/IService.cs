﻿using HRMDAL.Entites;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;


namespace HRMBAL
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    public interface IService
    {

        void AddEmployee(HRMDAL.Entites.Employee emp);


        List<HRMDAL.Entites.Employee> RetriveEmpIDImage(int EmpID);


        List<HRMDAL.Entites.StateCity> GetStates();


        List<HRMDAL.Entites.City> GetCity(int StateID);


        void AddBankDetails(BankDetails bank);


        DataSet CountryList();


        DataTable StateList(int CountryID);


        DataTable CityList(int StateID);


        DataSet GetEmployeeInfo(int empid);


        bool CheckEmpId(int empid);


        bool GetBankDetailsById(int empid);


        DataSet GetBankById(int empid);


        List<BankDetails> UpdateBankById(int empid);


        void AddEducationDetails(Education edu);


        void AddPassport(Passport pass);


        void AddIDProof(IDProof idproof);


        void LoanDetails(LoanDetails loanDetails);


        DataSet GetLoanDetails(int empid);


        void FamilyNomination(FamilyNomination familyNomination);


        DataSet GetFamilyNomination(int empid);


        DataSet GetPayslipDetails(int empid);


        List<Identity> GetEmpid();


        DataSet GetEmployeePayslip(int empid);


        void AddPayslip(int empid, string empname, string month, string year, string currsalary, string compname);


        void AddNewPayrollDetails(PaySlip payslip);


        DataSet GetEmployeeDetailsPayslip(int empid);


        decimal GetEmployeeGross(int empid);


        int GetEmployeeChildCount(int empid);


        DataSet GetReportingManagers();

        bool LoginRep(int empID);


        void Add(int empid, string password);


        HRMDAL.Entites.Login GetRoleID(int empid, string password);

        void ApplyLeav(HRMDAL.Entites.ApplyLeave App);


        DataSet GetLeaveQuota();


        DataSet GetLeaveHistory(int empId);


        DataSet GetAllLeavesPending();


        void ApproveLeaves(int empid, DateTime fromdate);

        void DailyAttend(HRMDAL.Entites.DailyAttendance att);


        void OnDutyApply(HRMDAL.Entites.ApplyOnDuty aod);


        DataSet GetOnDutyHistory(int empId);


        DataSet GetAttendanceRecord(int empId, DateTime startdate, DateTime enddate);


        string GetApproverByID(int empId);     

    }

}
