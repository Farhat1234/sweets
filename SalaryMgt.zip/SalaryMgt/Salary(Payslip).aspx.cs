﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.Salary_Mgt
{
    public partial class Salary_Payslip_ : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;
       // HRMRef.PaySlip payslip;

        HRMBAL.BALService Proxy;
        HRMDAL.Entites.PaySlip payslip;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            payslip = new HRMDAL.Entites.PaySlip();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                payslip.EmpID = Convert.ToInt32(txtEmpID.Text);
                payslip.EmpName = txtEmpName.Text;
                payslip.CompName = txtCompName.Text;
                payslip.Designation = txtDesignation.Text;
                payslip.ProfessionTax = Convert.ToDecimal(txtProfessionTax.Text);
                payslip.PreviousSalary = Convert.ToDecimal(txtPrevSalary.Text);
                payslip.Increment = Convert.ToInt32(txtIncreament.Text);
                decimal gorss = GetGrossSalary(Convert.ToDecimal(payslip.Increment), Convert.ToDecimal(payslip.PreviousSalary));
                payslip.CurrentSalary = (gorss + payslip.PreviousSalary);
                //payslip.NetSalary = Convert.ToDecimal(txtNETSalary.Text);
                payslip.Comments = txtComments.Text;
                Proxy.AddNewPayrollDetails(payslip);
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Salary assigned for the Employee')", true);
                ClearFields();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void ClearFields()
        {
            txtEmpID.Text = string.Empty;
            txtEmpName.Text = string.Empty;
            txtCompName.Text = string.Empty;
            txtDesignation.Text = string.Empty;
            txtProfessionTax.Text = string.Empty;
            txtPrevSalary.Text = string.Empty;
            txtIncreament.Text = string.Empty;
            //txtNETSalary.Text = string.Empty;
            txtComments.Text = string.Empty;
        }

        public Decimal GetGrossSalary(Decimal increment, Decimal previousSalary)
        {
            Decimal gross = ((increment / 100) * previousSalary);
            return gross;
        }
    }
}