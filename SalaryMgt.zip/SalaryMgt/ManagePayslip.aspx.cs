﻿using HumanResourceApplication.HRMRef;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HumanResourceApplication.SalaryMgt
{
    public partial class ManagePayslip : System.Web.UI.Page
    {
        //HRMRef.Service1Client Proxy;

        HRMBAL.BALService Proxy;

        protected void Page_Load(object sender, EventArgs e)
        {
            Proxy = new HRMBAL.BALService();
            if (!Page.IsPostBack)
            {
                List<HRMDAL.Entites.Identity> listiden = Proxy.GetEmpid();
                ddlEmpID.DataSource = listiden;
                ddlEmpID.DataTextField = "EmpID";
                ddlEmpID.DataValueField = "EmpName";
                ListItem l = new ListItem();
                l.Text = "---Select---";
                l.Value = "-1";
                ddlEmpID.AppendDataBoundItems = true;
                ddlEmpID.Items.Add(l);
                ddlEmpID.DataBind();
            }
        }

        protected void ddlEmpID_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                int empid = ddlEmpID.SelectedItem.Text == "---Select---" ? 0 : Convert.ToInt32(ddlEmpID.SelectedItem.Text);
                grdManagePayslip.DataSource = Proxy.GetEmployeePayslip(empid);
                grdManagePayslip.DataBind();
            }
            catch
            {
                throw;
            }
        }

        protected void grdManagePayslip_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            if (e.CommandName == "Approve")
            {
                int index = Convert.ToInt32(e.CommandArgument.ToString());

                Label lblEmpid = (Label)grdManagePayslip.Rows[index].FindControl("EmployeeID");
                Label lblEmpName = (Label)grdManagePayslip.Rows[index].FindControl("EmployeeName");
                Label lblCompName = (Label)grdManagePayslip.Rows[index].FindControl("CompanyName");
                Label lblCurrSalary = (Label)grdManagePayslip.Rows[index].FindControl("CurrentSalary");

                Proxy.AddPayslip(Convert.ToInt32(lblEmpid.Text), lblEmpName.Text.ToString(), ddlMonth.SelectedItem.Text.ToString(), ddlYear.SelectedItem.Text.ToString(), lblCurrSalary.Text.ToString(), lblCompName.Text.ToString());
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "alertMessage", "alert('Salary Approved')", true);
                ddlEmpID.SelectedValue = "-1";
                ddlMonth.SelectedValue = "-1";
                ddlYear.SelectedValue = "-1";
            }
        }
    }
}