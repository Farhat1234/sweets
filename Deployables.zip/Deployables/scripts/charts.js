$(function () {

    /**
     * Pie charts data and options used in many views
     */

    $("span.pie").peity("pie", {
        fill: ["#1f5671", "#edf0f5"]
    });

    $(".line").peity("line",{
        fill: '#1f5671',
        stroke:'#edf0f5'
    });

    $(".bar").peity("bar", {
        fill: ["#1f5671", "#edf0f5"]
    });

    $(".bar_dashboard").peity("bar", {
        fill: ["#1f5671", "#edf0f5"]
    })
});
